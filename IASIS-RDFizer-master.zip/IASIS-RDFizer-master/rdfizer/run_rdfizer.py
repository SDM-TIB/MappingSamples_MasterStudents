from rdfizer.semantify import semantify
semantify("configfile.ini")
