# from neo4jrestclient.client import GraphDatabase
# from neo4jrestclient import client
from neo4j.v1 import GraphDatabase, basic_auth
import csv
import os
import logging
import sys, traceback

logFormatter = logging.Formatter("%(asctime)s [%(threadName)-12.12s] [%(levelname)-5.5s]  %(message)s")
logger = logging.getLogger()
if not logger.handlers:

    logger.setLevel(logging.INFO)
    fileHandler = logging.FileHandler("{0}/{1}.log".format('data', 'semantic_enrichment'))
    fileHandler.setLevel(logging.INFO)
    fileHandler.setFormatter(logFormatter)

    logger.addHandler(fileHandler)

    consoleHandler = logging.StreamHandler()
    consoleHandler.setLevel(logging.INFO)
    consoleHandler.setFormatter(logFormatter)
    logger.addHandler(consoleHandler)


def convert_neo4j2csv():
    try:
        neo4jurl = os.environ['NEO4J_ENDPOINT_IP']
        user = os.environ['NEO4J_ENDPOINT_USER']
        passwd = os.environ['NEO4J_ENDPOINT_PASS']
        if len(user) > 0:
            db = GraphDatabase.driver(neo4jurl, auth=basic_auth(user, passwd))
        else:
            db = GraphDatabase.driver(neo4jurl)
        logger.info("query 1: MATCH (p:Annotation) RETURN p.id as id, p.label as label, p.semantic_types as semantic_types")
        q = "MATCH (p:Annotation) RETURN p.id as id, p.label as label, p.semantic_types as semantic_types"
        # results = db.query(q, data_contents=True)
        with db.session() as session:
            results = session.run(q)

        with open("query_annotation.csv", 'w', newline="", encoding='utf8') as myfile:
            wr = csv.writer(myfile, quoting=csv.QUOTE_ALL)
            wr.writerow(["id", "label", "semantic_types"])
            for r in results:
                wr.writerow(r)

        logger.info("query 2: MATCH (p:Publication) RETURN p.pmid as pmid, p.title as title, p.year as year, p.journal as journal, p.authors as authors")
        q = "MATCH (p:Publication) RETURN p.pmid as pmid, p.title as title, p.year as year, p.journal as journal, p.authors as authors"
        with db.session() as session:
            results = session.run(q)
        with open("query_publication.csv", 'w', newline="", encoding='utf8') as myfile:
            wr = csv.writer(myfile, quoting=csv.QUOTE_ALL)
            wr.writerow(["pmid", "title", "year", "journal", "authors"])
            for r in results:
                wr.writerow(r)

        logger.info("query 3: MATCH (p:Publication)-[r:HAS_TOPIC]->(a:Annotation) RETURN p.pmid as subject, type(r) as predicate, a.id as object, r.confidence as confidence")
        q = "MATCH (p:Publication)-[r:HAS_TOPIC]->(a:Annotation) RETURN p.pmid as subject, type(r) as predicate, a.id as object, r.confidence as confidence"
        with db.session() as session:
            results = session.run(q)
        with open("query_has_topic.csv", 'w', newline="", encoding='utf8') as myfile:
            wr = csv.writer(myfile, quoting=csv.QUOTE_ALL)
            wr.writerow(["subject", "predicate", "object", "confidence"])
            for r in results:
                wr.writerow(r)

        q = "MATCH (p:Annotation)-[r:MENTIONED_IN]->(a:Publication) RETURN p.id as subject, type(r) as predicate, a.pmid as object, r.confidence as confidence"
        logger.info("query 4:" + q)
        with db.session() as session:
            results = session.run(q)
        with open("query_mentioned_in.csv", 'w', newline="", encoding='utf8') as myfile:
            wr = csv.writer(myfile, quoting=csv.QUOTE_ALL)
            wr.writerow(["subject", "predicate", "object", "confidence"])
            for r in results:
                wr.writerow(r)

        q = "MATCH (a:Annotation)-[r]->(b:Annotation) RETURN a.id as subject, type(r) as predicate, b.id as object, r.confidence as confidence, r.resources as resources, r.negation as negation"
        logger.info("query 5" + q)
        with db.session() as session:
            results = session.run(q)
        with open("query_anno_anno.csv", 'w', encoding='utf8') as myfile:
            wr = csv.writer(myfile, quoting=csv.QUOTE_ALL)
            wr.writerow(["subject", "predicate", "object", "confidence", "resources", "negation"])
            for r in results:
                wr.writerow(r)
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        emsg = repr(traceback.format_exception(exc_type, exc_value,
                                               exc_traceback))
        logger.error("Exception while creating csv file from Neo4j: " + str(emsg))
