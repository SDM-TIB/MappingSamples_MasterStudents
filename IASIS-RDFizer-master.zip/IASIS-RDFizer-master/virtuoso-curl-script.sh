#!/usr/bin/env bash
cd /data
echo "loading ...."

virtuosoIP=$1
virtuosoUser=$2
virtuosoPass=$3
virtuosoPort=$4
virtuosoGraph=$5
outputfolder=$6
dumpstrip="ld_dir('$outputfolder', '*.nt', '$virtuosoGraph');"

echo "ld_dir('$outputfolder', '*.nt', '$virtuosoGraph');" >> load_data.sql
echo "rdf_loader_run();" >> load_data.sql

cat load_data.sql
isql-v $virtuosoIP:$virtuosoPort -U $virtuosoUser -P $virtuosoPass < load_data.sql
rm load_data.sql

#for filename in `ls -v $outputfolder/*`; do
#
#    curl -X PUT --digest -u "$virtuosoUser:$virtuosoPass" -H "Content-Type:text/turtle" -T $filename -G "http://$virtuosoIP:$virtuosoPort/sparql-graph-crud-auth" --data-urlencode "graph=$virtuosoGraph"
#done;

echo "Done loading!"