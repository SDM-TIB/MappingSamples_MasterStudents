#!/usr/bin/env python3
import pika
import sys
import json 
import os
import logging
import traceback
from neo4j_annotations import convert_neo4j2csv
from rdfizer.rdfizer.semantify import semantify
from pika.exceptions import ConnectionClosed
from multiprocessing import Process
import time

# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)
# handler = logging.StreamHandler()#FileHandler('/data/semantic_enrichment.log')
# handler.setLevel(logging.INFO)
# formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
# handler.setFormatter(formatter)
# logger.addHandler(handler)


logFormatter = logging.Formatter("%(asctime)s [%(threadName)-12.12s] [%(levelname)-5.5s]  %(message)s")
logger = logging.getLogger()
if not logger.handlers:
    logger.setLevel(logging.INFO)
    fileHandler = logging.FileHandler("{0}/{1}.log".format('data', 'semantic_enrichment'))
    fileHandler.setLevel(logging.INFO)
    fileHandler.setFormatter(logFormatter)

    logger.addHandler(fileHandler)

    consoleHandler = logging.StreamHandler()
    consoleHandler.setLevel(logging.INFO)
    consoleHandler.setFormatter(logFormatter)
    logger.addHandler(consoleHandler)


def open_output_connection():
    credentials = pika.PlainCredentials('guest', 'test12')
    connection = pika.BlockingConnection(
        pika.ConnectionParameters(host=os.environ['RABBITMQ_IP'], port=os.environ['RABBITMQ_PORT'], credentials=credentials))
    channel = connection.channel()
    channel.queue_declare(queue='iasis.semantic_enrichment.queue', durable=True, auto_delete=False)

    return connection, channel


def produce_output(message):
    connection, channel = open_output_connection()
    channel.basic_publish(exchange='iasis.direct',
                          routing_key='iasis.semnatic_enrichment.routingkey',
                          body=message)
    connection.close()


def run_program(m):
    logger.info("Executing job id: " + str(m['jobID']))
    producer(m)


def producer(message):
    errmsgs = []
    try:
        logger.info("Semantifying Lung Cancer patient data from Clinical Notes..")
        outputfolder, status1 = semantify("/data/configs/lc_notes/configfile.ini")
        if status1:
            virtuosoIP = os.environ["LC_NOTES_SPARQL_ENDPOINT_IP"]
            virtuosoUser = os.environ["LC_NOTES_SPARQL_ENDPOINT_USER"]
            virtuosoPass = os.environ["LC_NOTES_SPARQL_ENDPOINT_PASSWD"]
            virtuosoPort = os.environ["LC_NOTES_SPARQL_ENDPOINT_PORT"]
            virtuosoGraph = os.environ["LC_NOTES_SPARQL_ENDPOINT_GRAPH"]
            os.system("/app/virtuoso-curl-script.sh " + virtuosoIP + " " + virtuosoUser + " " + virtuosoPass + " " +
                      virtuosoPort + " " + virtuosoGraph + " " + outputfolder)
            logger.info("Lung Cancer patient data Semantified sucessfully!")

        else:
            errmsgs.append("Error during semantification of Lung Cancer patients data")
            logger.error("Error during semantification of Lung Cancer patients data")

    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        emsg = repr(traceback.format_exception(exc_type, exc_value,
                                               exc_traceback))
        logger.error("Exception while semantifying .LC.. " + str(emsg))
        errmsgs.append("An error occurred during semantification of Lung Cancer patients data" + str(emsg))

    try:
        logger.info("Semantifying Dementia patient data from ..")
        outputfolder, status1 = semantify("/data/configs/dementia/configfile.ini")
        if status1:
            virtuosoIP = os.environ["DEMENTIA_SPARQL_ENDPOINT_IP"]
            virtuosoUser = os.environ["DEMENTIA_SPARQL_ENDPOINT_USER"]
            virtuosoPass = os.environ["DEMENTIA_SPARQL_ENDPOINT_PASSWD"]
            virtuosoPort = os.environ["DEMENTIA_SPARQL_ENDPOINT_PORT"]
            virtuosoGraph = os.environ["DEMENTIA_SPARQL_ENDPOINT_GRAPH"]
            os.system("/app/virtuoso-curl-script.sh " + virtuosoIP + " " + virtuosoUser + " " + virtuosoPass + " " +
                      virtuosoPort + " " + virtuosoGraph + " " + outputfolder)
            logger.info("Dementia patients data Semantified sucessfully!")

        else:
            errmsgs.append("Error during semantification of Dementia patients data")
            logger.error("Error during semantification of Dementia patients data")

    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        emsg = repr(traceback.format_exception(exc_type, exc_value,
                                               exc_traceback))
        logger.error("Exception while semantifying .dementia.. " + str(emsg))
        errmsgs.append("An error occurred during semantification of Dementia patients data" + str(emsg))

    try:
        logger.info("Semantifying Genomic data from LC Images ..")
        outputfolder, status = semantify("/data/configs/lc_images/configfile.ini")
        if status:
            virtuosoIP = os.environ["LC_IMAGES_SPARQL_ENDPOINT_IP"]
            virtuosoUser = os.environ["LC_IMAGES_SPARQL_ENDPOINT_USER"]
            virtuosoPass = os.environ["LC_IMAGES_SPARQL_ENDPOINT_PASSWD"]
            virtuosoPort = os.environ["LC_IMAGES_SPARQL_ENDPOINT_PORT"]
            virtuosoGraph = os.environ["LC_IMAGES_SPARQL_ENDPOINT_GRAPH"]
            os.system(
                "/app/virtuoso-curl-script.sh " + virtuosoIP + " " + virtuosoUser + " " + virtuosoPass + " " +
                virtuosoPort + " " + virtuosoGraph + " " + outputfolder)
            logger.info("LC Images data Semantified sucessfully!")
        else:
            logger.error("Error during semantification of LC Images data")
            errmsgs.append("Error during semantification of LC Images data")
            # produce_output(dd)

    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        emsg = repr(traceback.format_exception(exc_type, exc_value,
                                               exc_traceback))
        logger.error("Exception while semantifying .LC Images .. " + str(emsg))
        errmsgs.append("An error occured during semantification of LC Images  data," + str(emsg))
    logger.info("Semantification Finished!")

    try:
        logger.info("Semantifying Drug exploration data ..")
        outputfolder, status2 = semantify("/data/configs/drug/configfile.ini")
        outputfolder, status3 = semantify("/data/configs/pub/configfile.ini")
        outputfolder, status1 = semantify("/data/configs/drug_predictions/configfile.ini")
        if status1 and status2 and status3:
            virtuosoIP = os.environ["DRUG_SPARQL_ENDPOINT_IP"]
            virtuosoUser = os.environ["DRUG_SPARQL_ENDPOINT_USER"]
            virtuosoPass = os.environ["DRUG_SPARQL_ENDPOINT_PASSWD"]
            virtuosoPort = os.environ["DRUG_SPARQL_ENDPOINT_PORT"]
            virtuosoGraph = os.environ["DRUG_SPARQL_ENDPOINT_GRAPH"]
            os.system(
                "/app/virtuoso-curl-script.sh " + virtuosoIP + " " + virtuosoUser + " " + virtuosoPass + " " +
                virtuosoPort + " " + virtuosoGraph + " " + outputfolder)
            logger.info("Drug data Semantified sucessfully!")

        else:
            logger.error("Error during semantification of Drug exploration data")
            errmsgs.append("Error during semantification of Drug exploration data")

    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        emsg = repr(traceback.format_exception(exc_type, exc_value,
                                        exc_traceback))
        logger.error("Exception while semantifying ..Drug. " + str(emsg))
        errmsgs.append("An error occured during semantification of Drug data" + str(emsg))

    try:
        logger.info("Semantifying Genomic data from COSMIC ..")
        outputfolder, status = semantify("/data/configs/genomic/configfile.ini")
        if status:
            virtuosoIP = os.environ["GENOMIC_SPARQL_ENDPOINT_IP"]
            virtuosoUser = os.environ["GENOMIC_SPARQL_ENDPOINT_USER"]
            virtuosoPass = os.environ["GENOMIC_SPARQL_ENDPOINT_PASSWD"]
            virtuosoPort = os.environ["GENOMIC_SPARQL_ENDPOINT_PORT"]
            virtuosoGraph = os.environ["GENOMIC_SPARQL_ENDPOINT_GRAPH"]
            os.system(
                "/app/virtuoso-curl-script.sh " + virtuosoIP + " " + virtuosoUser + " " + virtuosoPass + " " +
                virtuosoPort + " " + virtuosoGraph + " " + outputfolder)
            logger.info("Genomic data Semantified sucessfully!")

        else:
            logger.error("Error during semantification of Genomic data")
            errmsgs.append("Error during semantification of Genomic data")
            # produce_output(dd)
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        emsg = repr(traceback.format_exception(exc_type, exc_value,
                                               exc_traceback))
        logger.error("Exception while semantifying ..COSMIC. " + str(emsg))
        errmsgs.append("An error occured during semantification of COSMIC data" + str(emsg))

    

    dd = json.dumps({
                     'jobID': message['jobID'],
                     'componentName': "iasis_semantic_enrichment",
                     "status": True,
                     "msg": " \n\t - ".join(errmsgs)
                    })
    produce_output(dd)


def callback(ch, method, properties, body):

    body = body.decode('utf-8')
    body = json.loads(body)
    logger.info("jobID %r has been started " % body['jobID'])
    run_program(body)
    logger.info("jobID %r has been concluded! " % body['jobID'])


def consumer(fcallback):
    #producer()
    credentials = pika.PlainCredentials('guest', 'test12')
    connection = pika.BlockingConnection(
        pika.ConnectionParameters(host=os.environ['RABBITMQ_IP'], port=os.environ['RABBITMQ_PORT'], credentials=credentials))
    channel = connection.channel()

    channel.exchange_declare(exchange='iasis.direct', exchange_type='direct', durable=True, auto_delete=False)

    queue_name = 'iasis.semantic_enrichment.queue'
    channel.queue_declare(queue=queue_name, durable=True, auto_delete=False)
    channel.queue_bind(exchange='iasis.direct', queue=queue_name,
                       routing_key='iasis.semantic_enrichment.routingkey')

    channel.basic_consume(queue_name, fcallback, auto_ack=True)

    logger.info("Semantic Enrichment is waiting messages via iasis.semantic_enrichment.queue .. ")

    channel.start_consuming()

    # time_to_sleep = 20
    # remaining = time_to_sleep
    # while remaining > 0:
    #     connection.process_data_events()
    #     time.sleep(5)
    #     remaining -= 5


def main():
    consumer(callback)


if __name__ == '__main__':
    main()

