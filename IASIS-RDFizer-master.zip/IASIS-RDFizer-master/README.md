# RDFizing_WP3

## Installing requierements

```
pip3 install requierements.txt
```

## Installing RabbitMQ Server
```
sudo apt-get install rabbitmq-server
```

## Example of a Config file

The config file has to be updated with location of the source folder

```
[default]
main_directory: /home/guillermobet/Documentos/Fraunhofer/ProjectIASIS/SemanticEnrichment

[datasets]
number_of_datasets: 1
output_folder: ${default:main_directory}/graph
remove_duplicate: yes

[dataset1]
name: ADSampleDataWP4CO
format: csv
mapping: ${default:main_directory}/mappings/AD_CO.ttl
```
## Example of a Mapping file

The mapping file has to be updated with location of the source folder.

```
<#Publication>
	rml:logicalSource [ rml:source "neo4j_query_annotation/query_publication.csv";
						rml:referenceFormulation ql:CSV ];
	rr:subjectMap [
		rr:template "http://project-iasis.eu/Publication/{pmid}";
		rr:class iasis:Publication;
	];
	rr:predicateObjectMap [
		rr:predicate dc:title;
		rr:objectMap [ rml:reference "title" ];
	];
	rr:predicateObjectMap [
		rr:predicate dc:pmid;
		rr:objectMap [ rr:template "http://project-iasis.eu/vocab/{pmid}" ];
	];
	rr:predicateObjectMap [	
		rr:predicate iasis:year;
		rr:objectMap [ rml:reference "year" ];
	];
	rr:predicateObjectMap [
		rr:predicate dc:journal;
		rr:objectMap [ rml:reference "journal" ];
	];
	rr:predicateObjectMap [	
		rr:predicate iasis:authors;
		rr:objectMap [ rml:reference "authors" ];
	].
```

## Running RDFizing_COSMIC RabbitMQ

Within this repository mapping and config files are provided.

Please update the config file with directory where this project reside.

Open 4 terminals. One to run rabbitmq server. The others to run in each one of these commands.

```
python3 wp3_component.py
```
```
python3 receiver.py
```
```
python3 sender.py {jobID:,name:}
```