#!/usr/bin/env bash

if [ ! -f /data/data_downloaded ]; then

    if [ -f /data/gdown.pl ]; then
        cd /data
        /data/gdown.pl
        tar -xvf data.tar.gz
        rm data.tar.gz
        touch /data/data_downloaded
    fi
fi
python3 /app/receiver.py