#!/usr/bin/env python3
import pika
import sys
import json
import os

#os.environ['RABBITMQ_IP'] = "10.115.83.18"
#os.environ['RABBITMQ_PORT'] = "5672"


def run_program(m):
    print("Executing job ", m)
    producer(m)


def producer(message):
    # os.environ['LOCAL_IP']
    credentials = pika.PlainCredentials('guest', 'test12')
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=os.environ['RABBITMQ_IP'], port=os.environ['RABBITMQ_PORT'], credentials=credentials))
    channel = connection.channel()
    channel.queue_declare(queue='iasis.semantic_enrichment.queue', durable=True, auto_delete=False)
    channel.basic_publish(exchange='iasis.direct',
                          routing_key='iasis.semantic_enrichment.routingkey',
                          body=message)
    print(" Orchestrator sent: ", message)
    connection.close()


def callback(ch, method, properties, body):
    body = body.decode('utf-8')
    # if body == "EOF":
    #     exit(0)

    # os.system("echo 'message from the ochestrator " + str(body) + "\n'")

    # print(body)
    body = json.loads(body)
    print(body)
    exit(0)
    # print(" [x] %r job %r has been concluded" % (method.routing_key, body))


def consumer(fcallback):
    credentials = pika.PlainCredentials('guest', 'test12')
    connection = pika.BlockingConnection(pika.ConnectionParameters(host=os.environ['RABBITMQ_IP'], port=os.environ['RABBITMQ_PORT'], credentials=credentials))
    channel = connection.channel()
    channel.exchange_declare(exchange='iasis.semantic_enrichment.direct',
                             exchange_type='direct', durable=True, auto_delete=False)

    queue_name = 'iasis.semantic_enrichment.queue'
    channel.queue_declare(queue=queue_name, durable=True, auto_delete=False)

    channel.queue_bind(exchange='iasis.direct',
                       queue=queue_name,
                       routing_key='iasis.semantic_enrichment.routingkey')

    channel.basic_consume(queue_name, fcallback, auto_ack=True)
    
    print('I am ochestrator [*] Waiting for executed jobs. To exit press CTRL+C')
    channel.start_consuming()


def main():
    msg = {"jobID":6}
    producer(json.dumps(msg))
    consumer(callback)


if __name__ == '__main__':
    main()
